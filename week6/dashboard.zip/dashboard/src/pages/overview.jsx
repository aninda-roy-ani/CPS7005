import React, { useEffect, useState } from "react";
import axios from "axios";

import Header from '../components/header';
import Footer from '../components/footer';

function Overview() {
    // create a variable to store our shares data
    const [sharesData, setSharesData] = useState({});

    // fetch data from api
    useEffect(() => {
        const fetchData = async () => {
            try {
                axios.defaults.baseURL = 'https://api.coingecko.com/api/v3';
                const response = await axios.get("coins/bitcoin");
                const data = response.data;
                setSharesData(data);
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };

        fetchData();
    }, []);

    return (
        <div>
            <Header />
            <div className="shares-data">
                <h2>Bitcoin Data</h2>
                <ul>
                    <li>Symbol: {sharesData.symbol}</li>
                    <li>Name: {sharesData.name}</li>
                    <li>Current Price (USD): ${sharesData.market_data?.current_price?.usd}</li>
                    <li>Market Cap (USD): ${sharesData.market_data?.market_cap?.usd}</li>
                    <li>Total Volume (USD): ${sharesData.market_data?.total_volume?.usd}</li>
                </ul>
            </div>
            <Footer />
        </div>
    );
}

export default Overview;
