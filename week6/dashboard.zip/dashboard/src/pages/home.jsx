import Footer from '../components/footer';
import Header from '../components/header';

function Home() {
    return (
        <div>
            <Header />
            <Footer />
        </div>
    );
}

export default Home;
