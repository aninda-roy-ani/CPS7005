import Footer from '../components/footer';
import Header from '../components/header';

function Error() {
    return (
        <div>
            <Header />
            <h1>Page not found!</h1>
            <Footer />
        </div>
    );
}

export default Error;
