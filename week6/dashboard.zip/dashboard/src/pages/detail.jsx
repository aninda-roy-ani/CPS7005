import Footer from '../components/footer';
import Header from '../components/header';

function Detail() {
    return (
        <div>
            <Header />
            <h1>Detail...</h1>
            <Footer />
        </div>
    );
}

export default Detail;
