import './footer.css';

function Footer () {
    return (
        <p>Copyright &#169; 2024. Aninda Roy Ani. All Rights Reserved.</p>
    );
}

export default Footer;